window.w1AppConfig = {
    'api.westpac.co.nz': {
        mf8HeaderRequired: true,
        domain: 'connect.westpac.co.nz',
        headers: {
            'X-IBM-Client-Id': '43255b9d-df41-4149-a3c9-4eecbfe01150',
            'X-IBM-Client-Secret': 'F1oE2qV3dV5vA7sP0xC2fD0tR1fV7iY3bA2oW2uX8hL6fT3fG8',
        },
        credentials: 'include',
    },
};
window.wupServerURL = 'https://kei-te-aha.westpac.co.nz/client/v3/web/wup?cid=windstar';
window.logServerURL = 'https://rangitaki.westpac.co.nz/api/v1/sendLogs';
window.atomicConfig = {
    apiHost: 'https://147-4.client-api.atomic.io',
    apiKey: 'atomic_key_1',
    environmentId: 'WBQypjNb',
};
window.atomicStreamContainers = {
    accountsPage: '3lro1QaJ',
    notificationPanel: 'm8xgg2xK',
};