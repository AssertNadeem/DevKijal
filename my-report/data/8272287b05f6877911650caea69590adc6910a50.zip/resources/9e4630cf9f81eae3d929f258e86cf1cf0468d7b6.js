(function () {
    window.onload = function(){
        var frameName = new ds07o6pcmkorn({
            openElementId: "#womens-refuge-shield-button"
        });
        frameName.init();
    }
})();
